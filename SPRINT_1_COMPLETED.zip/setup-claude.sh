#!/bin/sh

# ChiaSeGPU — Claude Code Setup Script (macOS/Linux)
# Auto-generated — configures Claude Code to use your API key

set -e

ENDPOINT_URL="https://llm.chiasegpu.vn"
API_KEY='sk-2f4073a2cf23884c06925405cce6361b08d59a7d825b79a3e9a0f5fd2e29b907'
HAIKU_MODEL="ccf/claude-opus-4-7"
OPUS_MODEL="ccf/claude-opus-4-7"
SONNET_MODEL="ccf/claude-opus-4-7"
TRACKING_URL="https://llm.chiasegpu.vn/v1/tracking"

RED=$(printf '\033[0;31m')
GREEN=$(printf '\033[0;32m')
YELLOW=$(printf '\033[1;33m')
BLUE=$(printf '\033[0;34m')
NC=$(printf '\033[0m')

echo "${BLUE}================================${NC}"
echo "${BLUE}  ChiaSeGPU Claude Code Setup${NC}"
echo "${BLUE}================================${NC}"
echo ""

if [ -z "$ENDPOINT_URL" ]; then
    echo "${RED}Error: Endpoint URL not configured${NC}"
    exit 1
fi
if [ -z "$API_KEY" ]; then
    echo "${RED}Error: API key not configured${NC}"
    exit 1
fi

MASKED_KEY=$(echo "$API_KEY" | cut -c 1-10)
echo "Endpoint URL: ${GREEN}$ENDPOINT_URL${NC}"
echo "API Key:      ${GREEN}${MASKED_KEY}...${NC}"
echo ""

backup_file() {
    f_path="$1"
    if [ -f "$f_path" ]; then
        cp "$f_path" "${f_path}.backup.$(date +%Y%m%d%H%M%S)"
        echo "${YELLOW}  Backed up: $f_path${NC}"
    fi
}

remove_claude_vars() {
    f_path="$1"
    if [ -f "$f_path" ]; then
        sed '/^export ANTHROPIC_/d' "$f_path" > "${f_path}.tmp" && mv "${f_path}.tmp" "$f_path"
        sed '/^# ChiaSeGPU configuration/d' "$f_path" > "${f_path}.tmp" && mv "${f_path}.tmp" "$f_path"
        sed '/^# Claude Code configuration/d' "$f_path" > "${f_path}.tmp" && mv "${f_path}.tmp" "$f_path"
        rm -f "${f_path}.tmp" 2>/dev/null || true
    fi
}

add_claude_vars() {
    f_path="$1"
    remove_claude_vars "$f_path"
    echo "" >> "$f_path"
    echo "# ChiaSeGPU configuration" >> "$f_path"
    echo "export ANTHROPIC_BASE_URL=\"$ENDPOINT_URL\"" >> "$f_path"
    echo "export ANTHROPIC_AUTH_TOKEN=\"$API_KEY\"" >> "$f_path"
}

# Install statusline script
install_statusline() {
    local statusline_file="$HOME/.claude/statusline.sh"
    mkdir -p "$HOME/.claude"

    echo "${BLUE}Installing statusline script...${NC}"

    # Write statusline script inline (no external download needed)
    cat > "$statusline_file" << 'STATUSLINE_EOF'
#!/bin/bash
# ChiaSeGPU Statusline Script for Claude Code
# Hiển thị balance, token usage và cost trên statusline

TRACKING_URL="PLACEHOLDER_TRACKING_URL"
API_KEY='PLACEHOLDER_API_KEY'

CACHE_DIR="${TMPDIR:-/tmp}/chiasegpu-statusline"
CACHE_FILE="$CACHE_DIR/tracking_cache.json"
CACHE_TTL=30

mkdir -p "$CACHE_DIR" 2>/dev/null

INPUT=""
if [ ! -t 0 ]; then
    INPUT=$(cat)
fi

parse_context() {
    local json="$1"
    CWD=$(echo "$json" | grep -o '"cwd"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*:.*"\([^"]*\)"/\1/' | head -1)
    MODEL=$(echo "$json" | grep -o '"display_name"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*:.*"\([^"]*\)"/\1/' | head -1)
    MODEL_ID=$(echo "$json" | grep -o '"model"[[:space:]]*:[[:space:]]*{[^}]*"id"[[:space:]]*:[[:space:]]*"[^"]*"' | grep -o '"id"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*:.*"\([^"]*\)"/\1/' | head -1)
    if [ -z "$MODEL_ID" ]; then
        MODEL_ID=$(echo "$json" | grep -o '"id"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*:.*"\([^"]*\)"/\1/' | head -1)
    fi
    INPUT_TOKENS=$(echo "$json" | grep -o '"input_tokens"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    CACHE_CREATION=$(echo "$json" | grep -o '"cache_creation_input_tokens"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    CACHE_READ=$(echo "$json" | grep -o '"cache_read_input_tokens"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    OUTPUT_TOKENS=$(echo "$json" | grep -o '"output_tokens"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    INPUT_TOKENS="${INPUT_TOKENS:-0}"
    CACHE_CREATION="${CACHE_CREATION:-0}"
    CACHE_READ="${CACHE_READ:-0}"
    OUTPUT_TOKENS="${OUTPUT_TOKENS:-0}"
    CONVERSATION_TOKENS=$((INPUT_TOKENS + CACHE_CREATION + CACHE_READ))
    MAX_TOKENS=$(echo "$json" | grep -o '"context_window_size"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    LINES_ADDED=$(echo "$json" | grep -o '"total_lines_added"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    LINES_REMOVED=$(echo "$json" | grep -o '"total_lines_removed"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    GIT_NUM_FILES=$(echo "$json" | grep -o '"gitNumStagedOrUnstagedFilesChanged"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    USED_PERCENTAGE=$(echo "$json" | grep -o '"used_percentage"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | head -1)
    CWD="${CWD:-$(pwd)}"
    GIT_NUM_FILES="${GIT_NUM_FILES:-0}"
    MODEL="${MODEL:-unknown}"
    MODEL_ID="${MODEL_ID:-}"
    CONVERSATION_TOKENS="${CONVERSATION_TOKENS:-0}"
    MAX_TOKENS="${MAX_TOKENS:-200000}"
    LINES_ADDED="${LINES_ADDED:-0}"
    LINES_REMOVED="${LINES_REMOVED:-0}"
    USED_PERCENTAGE="${USED_PERCENTAGE:-0}"
    GIT_BRANCH=""
    if [ -n "$CWD" ] && [ -d "$CWD" ] && command -v git >/dev/null 2>&1; then
        if git -C "$CWD" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
            GIT_BRANCH=$(git -C "$CWD" branch --show-current 2>/dev/null)
        fi
    fi
}

shorten_path() {
    local path="$1"
    local home="$HOME"
    path="${path/#$home/\~}"
    if [ ${#path} -gt 40 ]; then
        path=$(echo "$path" | awk -F'/' '{print $(NF-1)"/"$NF}')
    fi
    echo "$path"
}

format_model() {
    local model="$1"
    if echo "$model" | grep -qiE '(opus|sonnet|haiku)'; then
        local tier version
        tier=$(echo "$model" | grep -oiE '(opus|sonnet|haiku)' | head -1)
        tier="$(echo "${tier:0:1}" | tr '[:lower:]' '[:upper:]')${tier:1}"
        version=$(echo "$model" | grep -oE '[0-9]+[\.\-][0-9]+' | tail -1 | tr '-' '.')
        if [ -n "$version" ]; then
            echo "${tier}-${version}"
        else
            echo "$tier"
        fi
        return
    fi
    echo "$model" | cut -c1-18
}

format_tokens() {
    local num="$1"
    if [ "$num" -ge 1000000 ] 2>/dev/null; then
        echo "$((num / 1000000)).$(( (num % 1000000) / 100000 ))M"
    elif [ "$num" -ge 1000 ] 2>/dev/null; then
        echo "$((num / 1000))k"
    else
        echo "$num"
    fi
}

format_vnd() {
    local num="$1"
    local int_val
    int_val=$(printf "%.0f" "$num" 2>/dev/null || echo "$num")
    echo "$int_val" | sed ':a;s/\B[0-9]\{3\}\>/.&/;ta'
}

get_tracking() {
    local now
    now=$(date +%s)
    if [ -f "$CACHE_FILE" ]; then
        local cache_time
        cache_time=$(stat -c %Y "$CACHE_FILE" 2>/dev/null || stat -f %m "$CACHE_FILE" 2>/dev/null || echo "0")
        local age=$((now - cache_time))
        if [ "$age" -lt "$CACHE_TTL" ]; then
            cat "$CACHE_FILE"
            return 0
        fi
    fi
    if [ -n "$TRACKING_URL" ] && [ -n "$API_KEY" ]; then
        local response
        response=$(curl -s --max-time 5 -H "Authorization: Bearer $API_KEY" "$TRACKING_URL" 2>/dev/null)
        if [ -n "$response" ]; then
            echo "$response" > "$CACHE_FILE"
            echo "$response"
            return 0
        fi
    fi
    if [ -f "$CACHE_FILE" ]; then
        cat "$CACHE_FILE"
    fi
}

parse_tracking() {
    local json="$1"
    BALANCE=$(echo "$json" | grep -o '"balance"[[:space:]]*:[[:space:]]*[0-9.]*' | sed 's/.*:[[:space:]]*//' | head -1)
    LAST_TOKENS=$(echo "$json" | grep -o '"total_tokens"[[:space:]]*:[[:space:]]*[0-9]*' | sed 's/.*:[[:space:]]*//' | tail -1)
    LAST_COST=$(echo "$json" | grep -o '"total_cost"[[:space:]]*:[[:space:]]*[0-9.]*' | sed 's/.*:[[:space:]]*//' | tail -1)
    BALANCE="${BALANCE:-0}"
    LAST_TOKENS="${LAST_TOKENS:-0}"
    LAST_COST="${LAST_COST:-0}"
}

progress_bar() {
    local current="$1"
    local max="$2"
    local width=5
    if [ "$max" -eq 0 ] 2>/dev/null; then
        echo "▯▯▯▯▯"
        return
    fi
    local pct=$((current * 100 / max))
    local filled=$((pct * width / 100))
    local empty=$((width - filled))
    local bar=""
    for ((i=0; i<filled; i++)); do bar+="\033[32m▮\033[0m"; done
    for ((i=0; i<empty; i++)); do bar+="\033[90m▯\033[0m"; done
    echo "$bar"
}

main() {
    parse_context "$INPUT"
    local W="\033[97m" G="\033[32m" Y="\033[33m" R="\033[31m" C="\033[36m" DM="\033[90m" D="\033[0m"

    local line1=""
    local short_cwd
    short_cwd=$(shorten_path "$CWD")
    line1+="${C}${short_cwd}${D}"
    if [ -n "$GIT_BRANCH" ]; then
        line1+="  ${DM}⎇${D} ${W}${GIT_BRANCH}${D}"
        if [ "$GIT_NUM_FILES" -gt 0 ]; then
            line1+=" ${Y}(${GIT_NUM_FILES})${D}"
        fi
    fi
    if [ "$LINES_ADDED" -gt 0 ] || [ "$LINES_REMOVED" -gt 0 ]; then
        line1+="  ${G}+${LINES_ADDED}${D} ${R}-${LINES_REMOVED}${D}"
    fi

    local line2=""
    # Use used_percentage from Claude Code if available, otherwise calculate
    local ctx_pct=0
    if [ "$USED_PERCENTAGE" -gt 0 ] 2>/dev/null; then
        ctx_pct=$USED_PERCENTAGE
    elif [ "$MAX_TOKENS" -gt 0 ]; then
        ctx_pct=$((CONVERSATION_TOKENS * 100 / MAX_TOKENS))
    fi
    local ctx_bar
    ctx_bar=$(progress_bar "$ctx_pct" "100")
    line2+="$ctx_bar ${W}${ctx_pct}%${D}"

    local model_display
    model_display=$(format_model "$MODEL")
    line2+=" ${DM}│${D} ${W}${model_display}${D}"

    local tracking_data
    tracking_data=$(get_tracking)
    if [ -n "$tracking_data" ]; then
        parse_tracking "$tracking_data"
        if [ -n "$BALANCE" ] && [ "$BALANCE" != "0" ]; then
            local bal_fmt
            bal_fmt=$(format_vnd "$BALANCE")
            line2+=" ${DM}│${D} ${G}${bal_fmt}đ${D}"
        fi
        if [ -n "$LAST_TOKENS" ] && [ "$LAST_TOKENS" != "0" ]; then
            local last_tok_fmt last_cost_fmt
            last_tok_fmt=$(format_tokens "$LAST_TOKENS")
            last_cost_fmt=$(format_vnd "$LAST_COST")
            line2+=" ${DM}│${D} ${DM}Cost:${D} ${W}${last_tok_fmt} tokens${D} ${Y}${last_cost_fmt}đ${D}"
        fi
    fi

    echo -e "$line1"
    echo -e "$line2"
}

main
STATUSLINE_EOF

    # Replace placeholders with actual values
    sed -i "s|PLACEHOLDER_TRACKING_URL|$TRACKING_URL|g" "$statusline_file" 2>/dev/null || \
        sed -i '' "s|PLACEHOLDER_TRACKING_URL|$TRACKING_URL|g" "$statusline_file"
    sed -i "s|PLACEHOLDER_API_KEY|$API_KEY|g" "$statusline_file" 2>/dev/null || \
        sed -i '' "s|PLACEHOLDER_API_KEY|$API_KEY|g" "$statusline_file"

    chmod +x "$statusline_file"
    echo "  ${GREEN}✓ Installed ~/.claude/statusline.sh${NC}"
    return 0
}

update_settings_json() {
    settings_file="$HOME/.claude/settings.json"
    statusline_installed="$1"
    statusline_cmd="$HOME/.claude/statusline.sh"

    mkdir -p "$HOME/.claude"

    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo "${RED}Error: jq is required but not installed.${NC}"
        echo ""
        echo "Please install jq first:"
        echo "  ${BLUE}macOS:${NC}        brew install jq"
        echo "  ${BLUE}Ubuntu/Debian:${NC} sudo apt-get install -y jq"
        echo "  ${BLUE}Fedora/RHEL:${NC}   sudo dnf install -y jq"
        echo "  ${BLUE}Arch Linux:${NC}    sudo pacman -S jq"
        echo ""
        echo "Then run this script again."
        exit 1
    fi

    if [ ! -f "$settings_file" ]; then
        echo '{}' > "$settings_file"
    else
        backup_file "$settings_file"
    fi

    tmp_file=$(mktemp)

    if [ "$statusline_installed" = "true" ]; then
        jq --arg url "$ENDPOINT_URL" --arg key "$API_KEY" \
           --arg haiku "$HAIKU_MODEL" --arg opus "$OPUS_MODEL" --arg sonnet "$SONNET_MODEL" \
           --arg sl_cmd "$statusline_cmd" '
            .env.ANTHROPIC_BASE_URL = $url |
            .env.ANTHROPIC_AUTH_TOKEN = $key |
            .env.ANTHROPIC_DEFAULT_HAIKU_MODEL = $haiku |
            .env.ANTHROPIC_DEFAULT_OPUS_MODEL = $opus |
            .env.ANTHROPIC_DEFAULT_SONNET_MODEL = $sonnet |
            .env.CLAUDE_CODE_DISABLE_1M_CONTEXT = "1" |
            .disableLoginPrompt = true |
            .statusLine = {"type": "command", "command": $sl_cmd}
        ' "$settings_file" > "$tmp_file" && mv "$tmp_file" "$settings_file"
    else
        jq --arg url "$ENDPOINT_URL" --arg key "$API_KEY" \
           --arg haiku "$HAIKU_MODEL" --arg opus "$OPUS_MODEL" --arg sonnet "$SONNET_MODEL" '
            .env.ANTHROPIC_BASE_URL = $url |
            .env.ANTHROPIC_AUTH_TOKEN = $key |
            .env.ANTHROPIC_DEFAULT_HAIKU_MODEL = $haiku |
            .env.ANTHROPIC_DEFAULT_OPUS_MODEL = $opus |
            .env.ANTHROPIC_DEFAULT_SONNET_MODEL = $sonnet |
            .env.CLAUDE_CODE_DISABLE_1M_CONTEXT = "1" |
            .disableLoginPrompt = true
        ' "$settings_file" > "$tmp_file" && mv "$tmp_file" "$settings_file"
    fi
}

configure_file() {
    rc_file="$1"
    echo "  Processing $rc_file"
    backup_file "$rc_file"
    add_claude_vars "$rc_file"
    echo "  ${GREEN}✓ Updated $rc_file${NC}"
}

echo "${BLUE}Configuring shell environment...${NC}"

SHELL_FOUND=0
if [ -f "$HOME/.bashrc" ]; then
    configure_file "$HOME/.bashrc"
    SHELL_FOUND=1
fi
if [ -f "$HOME/.zshrc" ]; then
    configure_file "$HOME/.zshrc"
    SHELL_FOUND=1
fi
if [ "$SHELL_FOUND" -eq 0 ]; then
    echo "${YELLOW}  No .bashrc or .zshrc found${NC}"
fi

echo ""
STATUSLINE_INSTALLED="false"
if [ -n "$TRACKING_URL" ]; then
    if install_statusline; then
        STATUSLINE_INSTALLED="true"
    fi
else
    echo "${YELLOW}  Statusline: Skipped (no tracking URL)${NC}"
fi

echo ""
echo "${BLUE}Configuring Claude Code settings...${NC}"
update_settings_json "$STATUSLINE_INSTALLED"
echo "  ${GREEN}✓ Updated ~/.claude/settings.json${NC}"

echo ""
echo "${GREEN}================================${NC}"
echo "${GREEN}  Configuration Complete!${NC}"
echo "${GREEN}================================${NC}"
echo ""
echo "Claude Code is now configured:"
echo "  Endpoint:   ${BLUE}$ENDPOINT_URL${NC}"
echo "  API Key:    ${BLUE}${MASKED_KEY}...${NC}"
if [ "$STATUSLINE_INSTALLED" = "true" ]; then
    echo "  Statusline: ${GREEN}Enabled${NC} (balance, tokens, cost)"
fi
echo ""
echo "${YELLOW}Next steps:${NC}"
echo "  1. Restart your terminal or run: ${BLUE}source ~/.bashrc${NC}"
echo "  2. Run: ${BLUE}claude${NC}"
echo ""
